The zip file used in the tests contains the following files from https://github.com/kunalverma94/pokemon, coded by Kunal Verma:
snake.html
snake.min.css
snake.min.js